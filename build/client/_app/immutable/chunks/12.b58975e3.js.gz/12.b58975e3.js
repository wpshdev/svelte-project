import{default as t}from"../entry/clear-page.svelte.93c6a73a.js";export{t as component};
//# sourceMappingURL=12.b58975e3.js.map
