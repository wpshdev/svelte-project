import{default as t}from"../entry/our-team-page.svelte.a54f4249.js";export{t as component};
//# sourceMappingURL=14.70507c76.js.map
