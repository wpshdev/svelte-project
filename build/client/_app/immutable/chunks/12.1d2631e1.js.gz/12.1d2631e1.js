import{default as t}from"../entry/contact-us-page.svelte.0f25ecea.js";export{t as component};
//# sourceMappingURL=12.1d2631e1.js.map
