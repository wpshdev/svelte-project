import{default as t}from"../entry/page-page.svelte.5667d78d.js";export{t as component};
//# sourceMappingURL=15.02686e10.js.map
