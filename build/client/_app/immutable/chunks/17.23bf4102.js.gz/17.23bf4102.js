import{_ as r}from"./_page.0a462137.js";import{default as t}from"../entry/portfolio-page.svelte.881d592c.js";export{t as component,r as universal};
//# sourceMappingURL=17.23bf4102.js.map
