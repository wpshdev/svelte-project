import{default as t}from"../entry/our-team-page.svelte.d3b2c224.js";export{t as component};
//# sourceMappingURL=15.55a8ed62.js.map
