import{default as t}from"../entry/blog-layout.svelte.306bbfbb.js";export{t as component};
//# sourceMappingURL=2.a5022404.js.map
