import{default as t}from"../entry/privacy-layout.svelte.94f15154.js";export{t as component};
//# sourceMappingURL=7.f6c763f7.js.map
