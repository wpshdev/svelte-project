import{_ as r}from"./_page.7a0c7cb0.js";import{default as t}from"../entry/portfolio-_slug_-page.svelte.5667d78d.js";export{t as component,r as universal};
//# sourceMappingURL=18.3b3121ec.js.map
