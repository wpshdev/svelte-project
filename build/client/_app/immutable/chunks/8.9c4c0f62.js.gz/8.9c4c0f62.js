import{default as t}from"../entry/_page.svelte.7f24fa5b.js";export{t as component};
//# sourceMappingURL=8.9c4c0f62.js.map
