import{default as t}from"../entry/services-page.svelte.42048f5b.js";export{t as component};
//# sourceMappingURL=22.172ba42a.js.map
