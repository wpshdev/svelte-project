import{default as t}from"../entry/about-us-page.svelte.73ec82a2.js";export{t as component};
//# sourceMappingURL=9.11338b0f.js.map
