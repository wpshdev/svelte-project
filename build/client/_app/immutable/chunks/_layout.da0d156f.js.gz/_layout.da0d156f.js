const e=Object.freeze(Object.defineProperty({__proto__:null},Symbol.toStringTag,{value:"Module"}));export{e as _};
//# sourceMappingURL=_layout.da0d156f.js.map
