import{default as t}from"../entry/privacy-layout.svelte.306bbfbb.js";export{t as component};
//# sourceMappingURL=7.3c1a5fc8.js.map
