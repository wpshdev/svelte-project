import{default as t}from"../entry/page-page.svelte.30adb4f8.js";export{t as component};
//# sourceMappingURL=17.7a79308b.js.map
