import{_ as r}from"./_layout.da0d156f.js";import{default as t}from"../entry/layout.svelte.9b56e2b7.js";export{t as component,r as universal};
//# sourceMappingURL=6.97b639c6.js.map
