import{default as t}from"../entry/our-team-page.svelte.2911cd82.js";export{t as component};
//# sourceMappingURL=13.43830d5b.js.map
