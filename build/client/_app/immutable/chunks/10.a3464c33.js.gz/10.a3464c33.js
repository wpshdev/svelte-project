import{default as t}from"../entry/blog-page.svelte.be1cb5a1.js";export{t as component};
//# sourceMappingURL=10.a3464c33.js.map
