import{default as t}from"../entry/error.svelte.d8a0ce98.js";export{t as component};
//# sourceMappingURL=1.5c71d9eb.js.map
