import{default as t}from"../entry/page-_slug_-page.svelte.f1dfc76e.js";export{t as component};
//# sourceMappingURL=17.ccf5f3c4.js.map
