import{default as t}from"../entry/about-us-page.svelte.4eb57910.js";export{t as component};
//# sourceMappingURL=9.3101580f.js.map
