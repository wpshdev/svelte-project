import{default as t}from"../entry/articles-_slug_-page.svelte.502d4543.js";export{t as component};
//# sourceMappingURL=11.bff50a7b.js.map
