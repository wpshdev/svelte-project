import{default as t}from"../entry/privacy-layout.svelte.84a1a47f.js";export{t as component};
//# sourceMappingURL=7.7477d1ac.js.map
