import{default as t}from"../entry/privacy-page.svelte.ae64a8d4.js";export{t as component};
//# sourceMappingURL=20.86312a4b.js.map
