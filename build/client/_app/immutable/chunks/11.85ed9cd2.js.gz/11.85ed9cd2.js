import{default as t}from"../entry/articles-_slug_-page.svelte.ea5e6521.js";export{t as component};
//# sourceMappingURL=11.85ed9cd2.js.map
