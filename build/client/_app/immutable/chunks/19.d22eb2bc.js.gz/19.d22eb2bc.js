import{default as t}from"../entry/portfolio-page.svelte.61bd9be3.js";export{t as component};
//# sourceMappingURL=19.d22eb2bc.js.map
