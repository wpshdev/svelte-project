import{default as t}from"../entry/our-process-page.svelte.590f162a.js";export{t as component};
//# sourceMappingURL=14.de14d670.js.map
