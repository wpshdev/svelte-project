import{default as t}from"../entry/privacy-page.svelte.55d42590.js";export{t as component};
//# sourceMappingURL=21.860e0e7f.js.map
