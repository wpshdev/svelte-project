import{default as t}from"../entry/contact-page.svelte.7aa89b20.js";export{t as component};
//# sourceMappingURL=12.f00c452e.js.map
