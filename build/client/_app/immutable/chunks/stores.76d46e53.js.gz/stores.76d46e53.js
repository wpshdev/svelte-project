import"./index.d0f96b4d.js";import{s as e}from"./singletons.ec6cd3f4.js";const r=()=>{const s=e;return{page:{subscribe:s.page.subscribe},navigating:{subscribe:s.navigating.subscribe},updated:s.updated}},b={subscribe(s){return r().page.subscribe(s)}};export{b as p};
//# sourceMappingURL=stores.76d46e53.js.map
