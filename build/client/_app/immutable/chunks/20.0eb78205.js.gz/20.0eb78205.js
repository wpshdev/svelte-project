import{default as t}from"../entry/portfolio-_slug_-page.svelte.ad022d6c.js";export{t as component};
//# sourceMappingURL=20.0eb78205.js.map
