import{default as t}from"../entry/page-page.svelte.ec9af16c.js";export{t as component};
//# sourceMappingURL=16.a0e98b1d.js.map
