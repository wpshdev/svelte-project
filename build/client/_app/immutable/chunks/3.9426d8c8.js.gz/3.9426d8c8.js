import{default as t}from"../entry/articles-_slug_-layout.svelte.94f15154.js";export{t as component};
//# sourceMappingURL=3.9426d8c8.js.map
