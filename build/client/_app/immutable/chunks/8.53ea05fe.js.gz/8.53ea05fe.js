import{default as t}from"../entry/_page.svelte.322de14c.js";export{t as component};
//# sourceMappingURL=8.53ea05fe.js.map
