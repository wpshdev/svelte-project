import{default as t}from"../entry/page-_slug_-page.svelte.d7b1af45.js";export{t as component};
//# sourceMappingURL=16.b5ed741a.js.map
