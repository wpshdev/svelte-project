import{default as t}from"../entry/privacy-page.svelte.2ea9f771.js";export{t as component};
//# sourceMappingURL=19.36d9f800.js.map
