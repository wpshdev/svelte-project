import{default as t}from"../entry/our-team-_slug_-page.svelte.5061bcdc.js";export{t as component};
//# sourceMappingURL=16.5bd87c9e.js.map
