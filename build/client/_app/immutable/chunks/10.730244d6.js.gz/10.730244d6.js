import{default as t}from"../entry/articles-page.svelte.d85e794e.js";export{t as component};
//# sourceMappingURL=10.730244d6.js.map
