import{default as t}from"../entry/articles-page.svelte.d6b8b8d3.js";export{t as component};
//# sourceMappingURL=10.fc04a38a.js.map
