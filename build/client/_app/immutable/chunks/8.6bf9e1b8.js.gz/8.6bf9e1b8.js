import{default as t}from"../entry/_page.svelte.9af2c23b.js";export{t as component};
//# sourceMappingURL=8.6bf9e1b8.js.map
