import{default as t}from"../entry/error.svelte.e3392e02.js";export{t as component};
//# sourceMappingURL=1.69b52d95.js.map
