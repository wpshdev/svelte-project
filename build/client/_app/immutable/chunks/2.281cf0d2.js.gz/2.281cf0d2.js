import{default as t}from"../entry/articles-layout.svelte.94f15154.js";export{t as component};
//# sourceMappingURL=2.281cf0d2.js.map
