import{default as t}from"../entry/page-_slug_-page.svelte.84f27cb9.js";export{t as component};
//# sourceMappingURL=18.03f10e14.js.map
