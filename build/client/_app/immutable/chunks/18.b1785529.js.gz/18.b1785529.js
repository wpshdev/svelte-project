import{default as t}from"../entry/portfolio-page.svelte.16daa3b9.js";export{t as component};
//# sourceMappingURL=18.b1785529.js.map
