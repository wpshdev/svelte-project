import{default as t}from"../entry/our-team-_slug_-page.svelte.67b35523.js";export{t as component};
//# sourceMappingURL=15.74ba75a1.js.map
