import{_ as r}from"./_page.c1284534.js";import{default as t}from"../entry/portfolio-_slug_-page.svelte.23e5c15e.js";export{t as component,r as universal};
//# sourceMappingURL=19.b0f28148.js.map
