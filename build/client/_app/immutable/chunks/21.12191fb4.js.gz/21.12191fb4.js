import{default as t}from"../entry/services-page.svelte.29ff4c23.js";export{t as component};
//# sourceMappingURL=21.12191fb4.js.map
