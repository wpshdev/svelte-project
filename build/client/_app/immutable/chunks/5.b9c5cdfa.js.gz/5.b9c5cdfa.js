import{_ as r}from"./_layout.ed77219c.js";import{default as t}from"../entry/layout.svelte.b7dd9001.js";export{t as component,r as universal};
//# sourceMappingURL=5.b9c5cdfa.js.map
