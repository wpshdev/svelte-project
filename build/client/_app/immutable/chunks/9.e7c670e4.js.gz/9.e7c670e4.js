import{default as t}from"../entry/about-page.svelte.de1e0891.js";export{t as component};
//# sourceMappingURL=9.e7c670e4.js.map
