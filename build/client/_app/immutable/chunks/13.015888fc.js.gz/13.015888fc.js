import{default as t}from"../entry/contact-us-page.svelte.6bce698e.js";export{t as component};
//# sourceMappingURL=13.015888fc.js.map
