import{default as t}from"../entry/articles-_slug_-layout.svelte.84a1a47f.js";export{t as component};
//# sourceMappingURL=3.b704eb48.js.map
