import{default as t}from"../entry/articles-layout.svelte.84a1a47f.js";export{t as component};
//# sourceMappingURL=2.530c0c03.js.map
