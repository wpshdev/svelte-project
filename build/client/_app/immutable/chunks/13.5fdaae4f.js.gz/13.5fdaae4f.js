import{_ as r}from"./_page.02e0d143.js";import{default as t}from"../entry/our-process-page.svelte.62eb74aa.js";export{t as component,r as universal};
//# sourceMappingURL=13.5fdaae4f.js.map
