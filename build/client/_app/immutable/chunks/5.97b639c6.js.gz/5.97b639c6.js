import{_ as r}from"./_layout.5eee0b91.js";import{default as t}from"../entry/layout.svelte.9b56e2b7.js";export{t as component,r as universal};
//# sourceMappingURL=5.97b639c6.js.map
