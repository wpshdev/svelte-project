const e=Object.freeze(Object.defineProperty({__proto__:null},Symbol.toStringTag,{value:"Module"}));export{e as _};
//# sourceMappingURL=_layout.5eee0b91.js.map
