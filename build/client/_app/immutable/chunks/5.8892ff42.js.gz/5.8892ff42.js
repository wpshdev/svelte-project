import{_ as r}from"./_layout.ed77219c.js";import{default as t}from"../entry/layout.svelte.bf9c83ce.js";export{t as component,r as universal};
//# sourceMappingURL=5.8892ff42.js.map
