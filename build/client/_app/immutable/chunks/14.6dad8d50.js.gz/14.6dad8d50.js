import{default as t}from"../entry/our-team-_slug_-page.svelte.c895a968.js";export{t as component};
//# sourceMappingURL=14.6dad8d50.js.map
