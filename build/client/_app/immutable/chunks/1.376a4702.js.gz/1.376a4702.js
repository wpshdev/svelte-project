import{default as t}from"../entry/error.svelte.7138d0a2.js";export{t as component};
//# sourceMappingURL=1.376a4702.js.map
