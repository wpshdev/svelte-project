import"../chunks/axios.aba6f0e0.js";import{l}from"../chunks/_page.7a0c7cb0.js";export{l as load};
//# sourceMappingURL=portfolio-_slug_-page.ts.c653d673.js.map
