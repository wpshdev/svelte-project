import{S as e,i as t,s as a}from"../chunks/index.b4b99831.js";class o extends e{constructor(s){super(),t(this,s,null,null,a,{})}}export{o as default};
//# sourceMappingURL=page-page.svelte.30adb4f8.js.map
