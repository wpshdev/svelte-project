import{S as e,i as t,s as a}from"../chunks/index.8c538c3a.js";class o extends e{constructor(s){super(),t(this,s,null,null,a,{})}}export{o as default};
//# sourceMappingURL=page-page.svelte.ec9af16c.js.map
