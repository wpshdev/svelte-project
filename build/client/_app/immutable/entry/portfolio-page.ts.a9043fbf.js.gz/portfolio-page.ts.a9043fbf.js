import"../chunks/axios.aba6f0e0.js";import{l}from"../chunks/_page.0a462137.js";export{l as load};
//# sourceMappingURL=portfolio-page.ts.a9043fbf.js.map
