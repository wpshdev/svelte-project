import{S as e,i as t,s as a}from"../chunks/index.eb34a208.js";class o extends e{constructor(s){super(),t(this,s,null,null,a,{})}}export{o as default};
//# sourceMappingURL=portfolio-_slug_-page.svelte.5667d78d.js.map
