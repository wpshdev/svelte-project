import"../chunks/axios.aba6f0e0.js";import{l}from"../chunks/_page.c1284534.js";export{l as load};
//# sourceMappingURL=portfolio-_slug_-page.ts.1ae85379.js.map
