import"../chunks/axios.aba6f0e0.js";import{l}from"../chunks/_page.02e0d143.js";export{l as load};
//# sourceMappingURL=our-process-page.ts.aff9a95b.js.map
