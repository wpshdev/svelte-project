import{S as e,i as t,s as n}from"../chunks/index.eceac6f7.js";class l extends e{constructor(s){super(),t(this,s,null,null,n,{})}}export{l as component};
//# sourceMappingURL=17.e387ac8d.js.map
