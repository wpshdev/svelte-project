import{S as e,i as t,s as n}from"../chunks/index.d0f96b4d.js";class l extends e{constructor(s){super(),t(this,s,null,null,n,{})}}export{l as component};
//# sourceMappingURL=17.6c8c4aea.js.map
