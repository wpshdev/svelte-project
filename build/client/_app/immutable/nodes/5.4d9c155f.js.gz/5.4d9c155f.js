import{L as r}from"../chunks/layout.de396381.js";const e=Object.freeze(Object.defineProperty({__proto__:null},Symbol.toStringTag,{value:"Module"}));export{r as component,e as universal};
//# sourceMappingURL=5.4d9c155f.js.map
